CREATE DATABASE  IF NOT EXISTS `cs544` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `cs544`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: cs544
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course_offering`
--

DROP TABLE IF EXISTS `course_offering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_offering` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `course_offering_id` varchar(255) DEFAULT NULL,
  `course_id2` bigint(20) DEFAULT NULL,
  `location_id3` bigint(20) DEFAULT NULL,
  `end_date` tinyblob,
  `start_date` tinyblob,
  PRIMARY KEY (`id`),
  KEY `FK9m102w1lbrqc7e3a9oc0nv40f` (`course_id2`),
  KEY `FKr9ojf0n8i7t1dsbu86ity19g7` (`location_id3`),
  CONSTRAINT `FK9m102w1lbrqc7e3a9oc0nv40f` FOREIGN KEY (`course_id2`) REFERENCES `course` (`id`),
  CONSTRAINT `FKr9ojf0n8i7t1dsbu86ity19g7` FOREIGN KEY (`location_id3`) REFERENCES `location` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_offering`
--

LOCK TABLES `course_offering` WRITE;
/*!40000 ALTER TABLE `course_offering` DISABLE KEYS */;
INSERT INTO `course_offering` VALUES (1,'CS544-2016-09A-09D',1,1,'�\�\0sr\0\rjava.time.Ser�]��\"H�\0\0xpw\0\0\�x','�\�\0sr\0\rjava.time.Ser�]��\"H�\0\0xpw\0\0\�x'),(2,'CS544-2017-01A-01D',1,1,'�\�\0sr\0\rjava.time.Ser�]��\"H�\0\0xpw\0\0\�x','�\�\0sr\0\rjava.time.Ser�]��\"H�\0\0xpw\0\0\�x');
/*!40000 ALTER TABLE `course_offering` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-08 23:23:50
